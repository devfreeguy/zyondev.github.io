const navbar = document.querySelector('.menu');
const menuIcon = document.querySelector('#menu-icon');
const goContact = document.querySelector('#contact-us-button');
const goPortfolio = document.querySelector('#portfolio-button');

menuIcon.addEventListener('click', ()=> {
   console.log('Clicked');
   try {
      /* code */
   menuIcon.classList.toogle('/resources/icons/cancel.png');
   } catch (e) {}
   navbar.classList.toggle('active');
});

goContact.addEventListener('click', ()=> {
   console.log('Contacted us');
});

goPortfolio.addEventListener('click', ()=> {
   console.log('Went to portfolio');
});
